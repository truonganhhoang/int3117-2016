load("myPages.js");

beforeTest(function () {
	var driver = createDriver("http://testapp.galenframework.com", "1024x768");
	session.put("driver", driver);
});

test("My notes page", function() {
	var driver = session.get("driver");
	
	var welcomPage = new WelcomePage(driver);
	welcomPage.loginButton.click();
	
	var loginPage = new LoginPage(driver);
	loginPage.username.typeText("testuser@example.com");
	loginPage.password.typeText("test123");
	loginPage.loginButton.click();
	
	checkLayout(driver, "my-note.gspec", "desktop");
	
	driver.quit();
}
)

afterTest(function () {
	var driver = session.get("driver");
	driver.quit();
});