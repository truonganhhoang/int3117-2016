this.WelcomePage = $page("Welcome page", { 
	loginButton: ".button-login"
});

this.LoginPage = $page("Login page", {
	username: "input[name='login.username']",
	password: "input[name='login.password']",
	loginButton: ".button-login"
});

var welcomPage = new WelcomePage(driver);
welcomPage.loginButton.click();

var loginPage = new LoginPage(driver);
loginPage.waitForIt();

loginPage.username.typeText("testuser@example.com");
loginPage.password.typeText("test123");
loginPage.loginButton.click();